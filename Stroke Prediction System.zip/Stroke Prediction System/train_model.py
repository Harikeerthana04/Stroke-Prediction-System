import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle

# Example dataset (you can replace with your real CSV)
data = pd.DataFrame([
    [67, "Female", 1, 1, "Yes", "Self-employed", "Rural", 180.2, 31.5, "formerly smoked", 1],
    [25, "Male", 0, 0, "No", "Private", "Urban", 85.6, 22.4, "never smoked", 0],
    [50, "Male", 1, 0, "Yes", "Govt_job", "Urban", 140.0, 28.0, "smokes", 0],
    [32, "Female", 0, 0, "No", "Private", "Urban", 95.4, 23.0, "never smoked", 0],
    [75, "Female", 1, 1, "Yes", "Never_worked", "Rural", 200.1, 30.2, "Unknown", 1]
], columns=["age","gender","hypertension","heart_disease","ever_married","work_type",
            "Residence_type","avg_glucose_level","bmi","smoking_status","stroke"])

# Convert categorical to numeric
gender_map = {'Male':0, 'Female':1, 'Other':2}
married_map = {'No':0, 'Yes':1}
work_map = {'Private':0, 'Self-employed':1, 'Govt_job':2, 'Children':3, 'Never_worked':4}
residence_map = {'Urban':1, 'Rural':0}
smoke_map = {'never smoked':0, 'formerly smoked':1, 'smokes':2, 'Unknown':3}

for col, mapping in zip(["gender","ever_married","work_type","Residence_type","smoking_status"],
                        [gender_map, married_map, work_map, residence_map, smoke_map]):
    data[col] = data[col].map(mapping)

# Features and target
X = data.drop("stroke", axis=1)
y = data["stroke"]

# Train-test split (not really needed, just for completeness)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train RandomForest
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Save model
with open("stroke_model.pkl", "wb") as f:
    pickle.dump(model, f)

print("Model saved as stroke_model.pkl")
