from flask import Flask, render_template, request, redirect, flash, url_for, session
import csv
import os
import pickle
import numpy as np

app = Flask(__name__)
app.secret_key = "your_secret_key"

USERS_FILE = "users.csv"

# Ensure CSV exists
if not os.path.exists(USERS_FILE):
    with open(USERS_FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["name", "username", "phone", "password"])

# Load ML model
with open("stroke_model.pkl", "rb") as f:
    model = pickle.load(f)

# --- Home ---
@app.route('/')
def home():
    return render_template('index.html')

# --- Sign Up ---
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        username = request.form['username']
        phone = request.form['phone']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            flash("Passwords do not match!", "error")
            return redirect(url_for('signup'))

        # Check duplicate username/email
        with open(USERS_FILE, "r") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row["username"] == username:
                    flash("This username/email is already registered!", "error")
                    return redirect(url_for('signup'))

        # Save user
        with open(USERS_FILE, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([name, username, phone, password])

        flash("Signup successful! You can now sign in.", "success")
        return redirect(url_for('signin'))

    return render_template('signup.html')

# --- Sign In ---
@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        robot_checked = request.form.get('robot')

        if not robot_checked:
            flash("Please confirm you are not a robot.", "error")
            return redirect(url_for('signin'))

        with open(USERS_FILE, "r") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row["username"] == username and row["password"] == password:
                    session['name'] = row["name"]
                    flash("Signed in successfully!", "success")
                    return redirect(url_for('dashboard'))

        flash("Invalid username or password.", "error")
        return redirect(url_for('signin'))

    return render_template('signin.html')

# --- Dashboard ---
@app.route('/dashboard')
def dashboard():
    if 'name' not in session:
        flash("Please sign in first.", "error")
        return redirect(url_for('signin'))
    return render_template('dashboard.html', username=session['name'])

# --- Stroke Prediction ---
@app.route('/predict', methods=['POST'])
def predict():
    if 'name' not in session:
        flash("Please sign in first.", "error")
        return redirect(url_for('signin'))

    # Form inputs
    age = float(request.form['age'])
    gender = request.form['gender']
    hypertension = int(request.form['hypertension'])
    heart_disease = int(request.form['heart_disease'])
    ever_married = request.form['ever_married']
    work_type = request.form['work_type']
    residence = request.form['Residence_type']
    glucose = float(request.form['avg_glucose_level'])
    bmi = float(request.form['bmi'])
    smoking = request.form['smoking_status']

    # Map categorical
    gender_map = {'Male':0, 'Female':1, 'Other':2}
    married_map = {'No':0, 'Yes':1}
    work_map = {'Private':0, 'Self-employed':1, 'Govt_job':2, 'Children':3, 'Never_worked':4}
    residence_map = {'Urban':1, 'Rural':0}
    smoke_map = {'never smoked':0, 'formerly smoked':1, 'smokes':2, 'Unknown':3}

    features = np.array([[ 
        age,
        gender_map[gender],
        hypertension,
        heart_disease,
        married_map[ever_married],
        work_map[work_type],
        residence_map[residence],
        glucose,
        bmi,
        smoke_map[smoking]
    ]])

    prediction = model.predict(features)[0]
    result = "High risk of stroke" if prediction==1 else "Low risk of stroke"

    return render_template("prediction_result.html", username=session['name'], result=result)

# --- Logout ---
@app.route('/logout')
def logout():
    session.pop('name', None)
    flash("You have been logged out.", "success")
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
